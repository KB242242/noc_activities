import { NextResponse } from 'next/server';
import { readFile, stat } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

export async function GET() {
  try {
    const zipPath = path.join(process.cwd(), 'download', 'NOC_Activities_Project.zip');
    
    // Vérifier si le fichier existe
    if (!existsSync(zipPath)) {
      return NextResponse.json(
        { error: 'File not found. Please regenerate the zip file.' },
        { status: 404 }
      );
    }

    // Lire le fichier
    const fileBuffer = await readFile(zipPath);
    const fileStats = await stat(zipPath);

    // Retourner le fichier avec les headers appropriés
    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="NOC_Activities_Project.zip"',
        'Content-Length': fileStats.size.toString(),
        'Cache-Control': 'no-cache',
      },
    });
  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json(
      { error: 'Failed to download file' },
      { status: 500 }
    );
  }
}
